package com.example.molissa.npu_project;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Activity_Camera extends AppCompatActivity{

    Uri imgUri;
    ImageView imv;
    EditText name;
    EditText scientific_name;
    EditText distributed;
    EditText review;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_activity__camera);

        imv = (ImageView) findViewById(R.id.imageView2);
        name = (EditText) findViewById(R.id.editText);
        scientific_name = (EditText) findViewById(R.id.editText2);
        distributed = (EditText) findViewById(R.id.editText3);
        review = (EditText) findViewById(R.id.editText4);


        String dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
        String fname = "p" + System.currentTimeMillis()+".jpg"; //利用時間建立不重複的檔案名
        imgUri = Uri.parse("file://"+dir+"/"+fname);
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //啟動相機
        camera.putExtra(MediaStore.EXTRA_OUTPUT,imgUri);
        startActivityForResult(camera,100);

    }


    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode == Activity.RESULT_OK && requestCode == 100){
            Bitmap bmp = BitmapFactory.decodeFile(imgUri.getPath()); //將圖檔轉換為bitmap物件
            imv.setImageBitmap(bmp); //將照片顯示在ImageView中
        }
        else {
            Toast.makeText(this,"相片讀取失敗",Toast.LENGTH_LONG).show();
        }
    }
}
